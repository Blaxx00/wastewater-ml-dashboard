import WastewaterMLDashboard from './WastewaterMLDashboard';
function App() {
  return <WastewaterMLDashboard />;
}
export default App;
